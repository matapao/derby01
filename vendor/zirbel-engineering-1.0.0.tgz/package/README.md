# Shared browser adapter

`@zirbel/engineering/browser` owns Puppeteer launch options, protocol sessions,
console capture and cleanup for Zirbel and the games. It requires Node 24 and an
installed Chrome; `CHROME_PATH` overrides automatic Chrome/Chromium discovery.

From the Zirbel repository, install dependencies with `npm ci --ignore-scripts`.
`npm run build:engineering` builds JavaScript and declarations. Packing always
rebuilds from source, so consumers need neither TypeScript nor a sibling checkout:

```sh
npm pack --workspace @zirbel/engineering --pack-destination /tmp
```

Copy the resulting archive to the consumer's `vendor/zirbel-engineering-1.0.0.tgz`,
then install that local path with npm:

```sh
npm install --save-dev --ignore-scripts ./vendor/zirbel-engineering-1.0.0.tgz
```

Retain the archive and commit the lockfile. Use `npm ci --ignore-scripts`
for subsequent installs. Only the compiled public adapter ships.

Run `npm run build:engineering`, then `node --test tools/cdp.test.ts` from Zirbel
for the real Chrome contract tests.
`Chrome.close()` closes its selected browser, including a connected browser, and
rejects pending calls. `Page.close()` waits for its target to disappear and is
idempotent. `dispose()` releases capture listeners when detaching from an existing
target.
